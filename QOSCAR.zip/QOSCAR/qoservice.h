#ifndef QOSERVICE_H
#define QOSERVICE_H

#include <QObject>

#include "qoscaradditional.h"


class QOSERVICE : public QObject
{
    Q_OBJECT

    public:
        QOSERVICE(const quint16 fusFamNum, const quint16 fusFamVersion,
                  const quint16 fusToolId, const quint16 fusToolVersion);
        QUShort usFamNum;
        QUShort usFamVersion;
        QUShort usToolId;
        QUShort usToolVersion;
        /*
        void setParams(const quint16 usFamNum, const quint16 usFamVersion,
                       const quint16 usToolId, const quint16 usToolVersion);
        */
        QByteArray toByteArray(void);
};

QByteArray create_OSERVICE__CLIENT_ONLINE(void);

#endif // QOSERVICE_H
