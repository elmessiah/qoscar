#include "qtlv.h"

QTlv::QTlv(void)
{
    notLast = true;
    length.data = 0x0000;
    type.data = 0x0000;
    value.clear();
}

QByteArray QTlv::toByteArray(void)
{
    QByteArray result;
    result.append(type.toByteArray());
    result.append(length.toByteArray());
    result.append(value);
    return result;
}

void QTlv::setData(const QString &d)
{
    if (d.length() < 65536)
    {
        value.clear();
        for (int i = 0; i < d.length(); i++)
            value.append(d.at(i));
        length.data = (quint16) d.length();
    }
}

void QTlv::setData(const QByteArray &d)
{
    if (d.length() < 65536)
    {
        value.clear();
        value = d;
        length.data = (quint16) d.length();
    }
}

void QTlv::setData(const quint8 &d)
{
    value.clear();
    length.data = 1;
    value[0] = d;
}

void QTlv::setData(const quint16 &d)
{
    value.clear();
    length.data = 2;
    value[0] = (d / 0x100);
    value[1] = (d % 0x100);
}

void QTlv::setData(const quint32 &d)
{
    value.clear();
    length.data = 4;
    value[0] = (d / 0x1000000);
    value[1] = (d / 0x10000);
    value[2] = (d / 0x100);
    value[3] = (d % 0x100);
}

void QTlv::appendData(const QString &d)
{
    for (int i = 0; i < d.length(); i++)
            value.append(d.at(i));
    length.data = (quint16) value.length();
}

void QTlv::appendData(const quint8 &d)
{
    length.data++;
    value[length.data - 1] = d;
}

void QTlv::appendData(const quint16 &d)
{
    length.data += 2;
    value[length.data - 2] = (d / 0x100);
    value[length.data - 1] = (d % 0x100);
}

void QTlv::appendData(const quint32 &d)
{
    length.data += 4;
    value[length.data - 4] = (d / 0x1000000);
    value[length.data - 3] = (d / 0x10000);
    value[length.data - 2] = (d / 0x100);
    value[length.data - 1] = (d % 0x100);
}

quint16 QTlv::getLength(void)
{
    return length.data + 4;
}

void QTlv::handleTlv(const QByteArray fData)
{
    QByteArray temp;
    bool ok;
    value.clear();

    temp.append(fData[0]);
    temp.append(fData[1]);
    type.data = temp.toHex().toUInt(&ok, 16);

    temp.append(fData[2]);
    temp.append(fData[3]);
    length.data = temp.toHex().toUInt(&ok, 16);

    for (int i = 4; i < length.data + 4; i++)
        value.append(fData[i]);

    notLast = (length.data + 4) < fData.length();
}
