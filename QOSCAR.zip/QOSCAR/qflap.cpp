#include "qflap.h"

QFlap::QFlap(const QByteArray fByteArr, const bool incoming)
{
    flapId = 0x2A;

    if (incoming){
        flapChannel.data = fByteArr[1];
        QByteArray temp;
        bool ok;
        temp.append(fByteArr[2]);
        temp.append(fByteArr[3]);
        seqNum.data = temp.toHex().toUInt(&ok, 16);
        temp.clear();
        temp.append(fByteArr[4]);
        temp.append(fByteArr[5]);
        dataSize.data = temp.toHex().toUInt(&ok, 16);
    }else{
        flapData.append(fByteArr);
        dataSize.data = flapData.size();
    }
}

QByteArray QFlap::toByteArray(const bool isFirst)
{
    QByteArray result;
    result.append(flapId);
    result.append(flapChannel.data);
    result.append(seqNum.toByteArray());
    if (isFirst)
        dataSize.data += 4;
    result.append(dataSize.toByteArray());

    if (isFirst){
        for (int i = 0; i < 3; i++)
                result.append((char) 0x00);
        result.append((char) 0x01);
    }

    result.append(flapData);
    return result;
}

unsigned char QFlap::getChannel(void)
{
    //return flapChannel;
}

QUShort QFlap::getSequence(void)
{
    /*QUShort result = *seqNum;
    return resut; */
}

QUShort QFlap::getDataSize(void)
{
    //return this->dataSize;
}

void QFlap::deleteArr(const quint32 size)
{
    flapData.remove(0, size);
}
