#include "qoscaradditional.h"

QUShort::QUShort(/*quint16 fData*/)
{
    //data = fData;
}

QULong::QULong(/*const quint32 fData*/)
{
    //data = fData;
}

QUShort8::QUShort8(void)
{
    //
}

QByteArray QUShort8::toByteArray(void)
{
    QByteArray packet;
    packet[0] = data;
    return packet;
}

QByteArray QUShort::toByteArray(void)
{
    QByteArray packet;
    packet[0] = (data / 0x100);
    packet[1] = (data % 0x100);
    return packet;
}

QByteArray QULong::toByteArray(void)
{
    QByteArray packet;
    packet[0] = (data / 0x1000000);
    packet[1] = (data / 0x10000);
    packet[2] = (data / 0x100);
    packet[3] = (data % 0x100);
    return packet;
}
