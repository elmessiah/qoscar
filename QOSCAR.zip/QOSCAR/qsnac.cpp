#include "qsnac.h"

QSnac::QSnac(void)
{
    //
}

QByteArray QSnac::toByteArray(void)
{
    QByteArray result;
    result.append(familyId.toByteArray());
    result.append(familySubType.toByteArray());
    result.append(snacFlags.toByteArray());
    result.append(snacReqId.toByteArray());
    result.append(snacData); //!!!
    return result;
}
void QSnac::setData(const QByteArray sData)
{
    snacData.append(sData);
}

void QSnac::handlePacket(const QByteArray sData)
{
    QByteArray tmp;
    bool ok;

    tmp.append(sData[0]);
    tmp.append(sData[1]);
    familyId.data = tmp.toHex().toUInt(&ok, 16);
    tmp.clear();
    tmp.append(sData[2]);
    tmp.append(sData[3]);
    familySubType.data = tmp.toHex().toUInt(&ok, 16);
    tmp.clear();
    tmp.append(sData[4]);
    tmp.append(sData[5]);
    snacFlags.data = tmp.toHex().toUInt(&ok, 16);
    tmp.clear();
    tmp.append(sData[2]);
    tmp.append(sData[3]);
    snacReqId.data = tmp.toHex().toUInt(&ok, 32);

    tmp.clear();
    tmp.append(sData);
    tmp.remove(0, 4);
    snacData.append(tmp);

    tmp.clear();
}
