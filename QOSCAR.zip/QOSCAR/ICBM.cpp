#include "ICBM.h"

QByteArray create_ICBM__MESSAGE_TO_HOST(const QString SN, const QString Message)
{
    QByteArray bArr;

    QTlv Tlv0501;
    Tlv0501.setType(0x0501);
    Tlv0501.setData((quint16) 0x0001);
    bArr.append(Tlv0501.toByteArray());

    QTlv Tlv0101;
    Tlv0101.setType(0x0101);
    QByteArray baTmp((quint16) 0x0000);
    for (int i = 0; i < 4; i++)
        baTmp.append((char) 0x00);
    QTextCodec* textCodec = QTextCodec::codecForName("Windows-1251");
    baTmp.append(textCodec->fromUnicode(Message));
    Tlv0101.setData(baTmp);

    bArr.append(Tlv0101.toByteArray());

    QTlv Tlv2;
    Tlv2.setType(0x0002);
    Tlv2.setData(bArr);

    QTlv Tlv3;
    Tlv3.setType(0x0003);

    QTlv Tlv6;
    Tlv6.setType(0x0006);

    QByteArray baSnac;
    QSnac Snac0406;
    Snac0406.setFamilyId(0x04);
    Snac0406.setSubType(0x06);
    Snac0406.setReqId(0x00000000);
    Snac0406.setFlags(0x0000);
    baSnac.append(Snac0406.toByteArray());

    for (int i = 0; i < 9; i++)
        baSnac.append((char) 0x00);

    baSnac.append((quint16) 0x01);
    baSnac.append((quint8) SN.length());
    baSnac.append(SN);
    baSnac.append(Tlv2.toByteArray());
    baSnac.append(Tlv3.toByteArray());
    baSnac.append(Tlv6.toByteArray());

    return baSnac;
}

QByteArray create_CLI_IDENT(const QIdent ident, const QString ScreenName,
                            const QString Password)
{
    QByteArray bArr;
    QTlv Tlv;
    Tlv.setData(ScreenName);
    Tlv.setType(0x01);
    bArr.append(Tlv.toByteArray());
    Tlv.setData(Password);
    Tlv.setType(0x02);
    bArr.append(Tlv.toByteArray());

    Tlv.setData(ident.clientName);
    Tlv.setType(0x03);
    bArr.append(Tlv.toByteArray());

    Tlv.setData(ident.majorVersion);
    Tlv.setType(0x17);
    bArr.append(Tlv.toByteArray());

    Tlv.setData(ident.minorVersion);
    Tlv.setType(0x18);
    bArr.append(Tlv.toByteArray());

    Tlv.setData(ident.lesserVersion);
    Tlv.setType(0x19);
    bArr.append(Tlv.toByteArray());

    Tlv.setData(ident.build);
    Tlv.setType(0x1A);
    bArr.append(Tlv.toByteArray());

    Tlv.setData(ident.unknown);
    Tlv.setType(0x16);
    bArr.append(Tlv.toByteArray());

    Tlv.setData(ident.subBuild);
    Tlv.setType(0x14);
    bArr.append(Tlv.toByteArray());

    Tlv.setData(ident.language);
    Tlv.setType(0x0F);
    bArr.append(Tlv.toByteArray());

    Tlv.setData(ident.country);
    Tlv.setType(0x0E);
    bArr.append(Tlv.toByteArray());

    return bArr;
};

QString unicodeToUtf8(const QByteArray &array)
{
        QByteArray msg2;

         for ( int i = 0; i < array.size(); i +=2)
         {
                 quint16 symbol = static_cast<quint16>((quint16)(array.at(i) * 0x100) + (quint8)array.at(i+1));

                 if ( symbol < 0x0080)
                         msg2.append((unsigned char) symbol);
                 else if (symbol < 0x0800) {
                     qDebug()<<msg2.toHex();
                         msg2.append(0xc0 | ( symbol >> 6));
                         msg2.append(0x80 | (symbol & 0x3f));
                 } else {
                         msg2.append(0xe0 | ( symbol >> 12));
                         msg2.append(0x80 | ((symbol >>6 )& 0x3f));
                         msg2.append(0x80 | (symbol & 0x3f));
                 }
         }

         return QString::fromUtf8(msg2);
}

/* Handling incoming message */
QMessage handleMessage(const QByteArray baMessage)
{
    QMessage mResult;
    QByteArray bArr(baMessage);
    QByteArray baTemp;
    bArr.remove(0, 16); // Delete Cookie and channel
    for (int i = 0; i < bArr[0]; i++)
        mResult.sSender.append(bArr.at(i + 1));

    while (bArr.size() > 0){
        if ((bArr.at(0) == (char) 0x01) && (bArr.at(1) == (char) 0x01))
            break;
        bArr.remove(0, 1);
    }
    QTlv Tlv0101;
    Tlv0101.handleTlv(bArr);
    bArr.remove(0, 8);
    for (int i = 0; i < Tlv0101.length.data - 4; i++)
        baTemp.append(bArr.at(i));

    mResult.sMessage.append(unicodeToUtf8(baTemp));
    return mResult;
}
