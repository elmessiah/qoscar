#ifndef QOSCARSOCK_H
#define QOSCARSOCK_H

#include <QObject>
#include <QSslSocket>
#include <QString>


class QOSCARSock : public QObject
{
    Q_OBJECT

    public:
        QOSCARSock();
        QSslSocket* Sock;

        bool isConnected(void) { return bOnline; }
        void connect(const QString fHost, const int fPort);
        QByteArray readAllData(void) { return Sock->readAll(); }

    private:
        bool bOnline;

    private slots:
        void fConnected(void);
        void fDisconnected(void);
        void fError(QAbstractSocket::SocketError socketError);
        void fReadyRead(void);

    signals:
        void sConnected(void);
        void sDisconnected(void);
        void sError(QAbstractSocket::SocketError);
        void sReadyRead(void);
};

#endif // QOSCARSOCK_H
