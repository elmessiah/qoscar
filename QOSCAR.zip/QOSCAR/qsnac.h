#ifndef QSNAC_H
#define QSNAC_H

#include <QObject>

#include "qoscaradditional.h"

class QSnac : public QObject
{
    Q_OBJECT

    public:
        QSnac(void);
        void setFamilyId(const quint16 fId){ familyId.data = fId; }
        void setSubType(const quint16 fST){ familySubType.data = fST; }
        void setFlags(const quint16 sFlags){ snacFlags.data = sFlags; }
        void setReqId(const quint32 sReqId){ snacReqId.data = sReqId; }
        void setData(const QByteArray sData);
        void handlePacket(const QByteArray sData);

        QByteArray toByteArray(void);

        QUShort familyId;
        QUShort familySubType;
        QUShort snacFlags;
        QULong snacReqId;
        QByteArray snacData;
};

#endif // QSNAC_H
