#ifndef QOSCARADDITIONAL_H
#define QOSCARADDITIONAL_H

#include <QObject>
#include <QByteArray>

//#include "qtlv.h"
//#include "OSCARConst.h"

class QUShort8 : public QObject
{
    public:
        QUShort8(void);
        QByteArray toByteArray(void);
        quint8 data;
};

class QUShort : public QObject
{
    public:
        QUShort(void);
        QByteArray toByteArray(void);
        quint16 data;
};

class QULong : public QObject
{
    public:
        QULong(void);
        QByteArray toByteArray(void);
        quint32 data;
};

struct QInterest {QUShort usCategory;
                  QString sInterest;};

struct QSNInfo {QString sNickName;
                QString sFirstName;
                QString sLastName;
                QString sEMail;
                QUShort usHomeCountry;
                QString sHomeCity;
                QString sHomeState;
                QString sHomeZip;
                QString sHomePhone;
                QString sHomeFax;
                QString sHomeCellular;
                QString sHomeStreet;
                QUShort usOriginalCountry;
                QString sOriginalCity;
                QString sOriginalState;
                QUShort8 us8GMT;
                QUShort usWorkCountry;
                QString sWorkCity;
                QString sWorkState;
                QString sWorkZip;
                QString sWorkPhone;
                QString sWorkFax;
                QString sWorkStreet;
                QString sWorkName;
                QString sWorkDepaertment;
                QUShort usWorkOccupation;
                QString sWorkPosition;
                QString sWorkWebPage;
                QUShort8 us8UserGender;
                QUShort usUserAge;
                QUShort8 us8UserMarital;
                QString sHomePage;
                QUShort usBirthYear;
                QUShort usBirthMonth;
                QUShort usBirthDay;
                QUShort usUserLang;
                QInterest  iInterest1,
                           iInterest2,
                           iInterest3,
                           iInterest4,
                           iAffiliation1,
                           iAffiliation2,
                           iAffilition3,
                           iPast1,
                           iPast2,
                           iPast3;
                QString sAbout;};


#endif // QOSCARADDITIONAL_H
