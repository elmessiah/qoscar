#include "qoscar.h"

QOSCAR::QOSCAR(QObject *parent): QObject(parent)
{
    OSCARSock = new QOSCARSock();
    QObject::connect(OSCARSock, SIGNAL(sConnected()), this, SLOT(oConnected()));
    QObject::connect(OSCARSock, SIGNAL(sDisconnected()), this, SLOT(oDisconnected()));
    QObject::connect(OSCARSock, SIGNAL(sError(QAbstractSocket::SocketError)), this,
                     SLOT(oError(QAbstractSocket::SocketError)));
    QObject::connect(OSCARSock, SIGNAL(sReadyRead()), this, SLOT(oReadyRead()));

    timer = new QTimer(this);
    timer->setInterval(60 * 1000);
    timer->start();
    connect(timer, SIGNAL(timeout()), this, SLOT(oTimeOut()));

    ident.clientName = "AIM";
    ident.majorVersion = 6;
    ident.minorVersion = 5;
    ident.lesserVersion = 3;
    ident.build = 104;
    ident.unknown = 0x010A;
    ident.subBuild = 30007;
    ident.language = "ru";
    ident.country = "ru";
    Status = Q_OFFLINE;
    loginStatus.data = STATUS_ONLINE;
    loginFlags.data = STATUS_DCCONT;
    bOnline = false;
}

QOSCAR::~QOSCAR()
{

}

/************************************************************/
/**************** SLOTS *************************************/
/***********************************************************/

void QOSCAR::oConnected(void)
{
    qDebug() << "Connected!";
}

void QOSCAR::oDisconnected(void)
{
    qDebug() << "Disconnected!";
    bOnline = false;
}

void QOSCAR::oError(QAbstractSocket::SocketError socketError)
{
    qDebug() << "Error: " << socketError;
}

void QOSCAR::oReadyRead(void)
{
    qDebug() << "Ready to Read!";
    qDebug() << "Reading data...";
    QByteArray allData(OSCARSock->readAllData());
    qDebug() << "Handling packet...";
    handlePacket(allData);
}

void QOSCAR::oTimeOut(void)
{
    QByteArray bArr;
    if (isOnline())
        sendFlap(KEEP_ALIVE_CHANNEL, bArr, false);
}

/**************************************************************/
/******** PROCEDURES ******************************************/
/**************************************************************/

/* Handling incoming packet */
void QOSCAR::handlePacket(const QByteArray dataArr)
{
    // if received FLAP
    if (dataArr.at(0) != FLAP_IDENT)
        return;

    QFlap flap(dataArr, true);

    if (flap.flapChannel.data == NEW_CHANNEL){ // New connection
        if (Status == Q_CONNECTING)
            send_CLI_IDENT();
        else
            send_CLI_COOKIE();
    }else
        if (flap.flapChannel.data == CLOSE_CHANNEL){ // Connection close
            QTlv Tlv;
            QByteArray tmpData(dataArr);
            tmpData.remove(0, 6);
            while (Tlv.notLast){
                Tlv.handleTlv(tmpData);
                tmpData.remove(0, Tlv.length.data + 4);

                if (Tlv.type.data == TLV_BOS_IDENT){
                    sBOSServer.append(Tlv.value);
                    sBOSServer.chop(5);
                }else
                if (Tlv.type.data == TLV_COOKIE_IDENT){
                    baBOSCookie.clear();
                    baBOSCookie.append(Tlv.value);
                    connectToBOS();
                }else
                if (Tlv.type.data == MISMATCH_NICK_OR_PASSWORD)
                    emit fError(QICQ, "MISMATCH_NICK_OR_PASSWORD");
                else
                if (Tlv.type.data == RATE_LIMITED)
                    emit fError(QICQ, "RATE_LIMITED");
            }
        }else
        if (flap.flapChannel.data == SNAC_CHANNEL){
            QByteArray tmpData(dataArr);
            handleSnac(tmpData);
        }
}

/* Handling SNAC */
void QOSCAR::handleSnac(const QByteArray dataArr)
{
    QSnac snac;
    QByteArray tmpData(dataArr);
    tmpData.remove(0, 6);
    snac.handlePacket(tmpData);

    if ((snac.familyId.data == 0x0001) && (snac.familySubType.data == 0x0003)){
        send_OSERVICE__SET_NICKINFO_FIELDS();
        send_OSERVICE__CLIENT_ONLINE();
        emit fLoggedIn();
        bOnline = true;
    }else
    if ((snac.familyId.data == 0x0004) && (snac.familySubType.data == 0x0007)){
        QMessage message = handleMessage(snac.snacData);
        qDebug() << "Message sender: " << message.sSender;
        qDebug() << "Message: " << message.sMessage;
        emit fMessageReceived(message);
    }
}

/* Sending CLI_IDENT */
void QOSCAR::send_CLI_IDENT(void)
{
    QByteArray bArr = create_CLI_IDENT(ident, ScreenName, roastPassword());
    sendFlap(NEW_CHANNEL, bArr, true);
}

/* Logging in */
void QOSCAR::login(const QString fSN, const QString fPass)
{
    if (Status != Q_OFFLINE){
        emit fError(QCLASS, "You are already logged in or trying to do it");
        return;
    }

    if ((fSN != "") && (fPass != "")){
        ScreenName = fSN;
        Password = fPass;
    }
    OSCARSock->connect("", 0);
    Status = Q_CONNECTING;
}

/* Roasting Password */
QString QOSCAR::roastPassword(void)
{
    QString result;
    for (int i = 0; i < Password.length(); i++){
        unsigned char tmp = Password.at(i).toAscii();
        unsigned char res = tmp ^ QRoastArray[i];
        result.append( res );
    }
    return result;
}

/* Increasing sequence */
void QOSCAR::incSequence(void)
{
    if (usSequence >= 0x8000)
        usSequence = 0;
    else
        usSequence++;
}

/* Connecting to BOS server */
void QOSCAR::connectToBOS(void)
{
    Status = Q_CONNECTING_TO_BOS;
    OSCARSock->Sock->disconnectFromHost();
    OSCARSock->connect(sBOSServer, 5190);
}

/* Sending CLI Cookie */
void QOSCAR::send_CLI_COOKIE(void)
{
    QTlv Tlv;
    Tlv.setType(0x0006);
    Tlv.setData(baBOSCookie);
    sendFlap(NEW_CHANNEL, Tlv.toByteArray(), true);
}
/* Sending CLIENT_ONLINE packet */
void QOSCAR::send_OSERVICE__CLIENT_ONLINE(void)
{
    QByteArray bArr = create_OSERVICE__CLIENT_ONLINE();
    sendSnac(0x0001, 0x0002, 0x0000, 0x00000000, bArr);
}

/* Setting xStatus, Status and DC information */
void QOSCAR::send_OSERVICE__SET_NICKINFO_FIELDS(void)
{
    QByteArray bArr;
    QTlv Tlv;

    //bArr.append(createTlv(0x0006, loginStatus.toByteArray()));

    Tlv.setType(0x0006);
    quint32 temp = (quint32) (loginFlags.data << 16) | loginStatus.data;
    Tlv.setData(temp);
    bArr.append(Tlv.toByteArray());

    /*
      Optional TLVs
    */
    sendSnac(0x0001, 0x001E, 0x0000, 0x00000000, Tlv.toByteArray());
}

/* Creating TLV packet */
QByteArray QOSCAR::createTlv(const quint16 usType, const QByteArray baData)
{
    QTlv result;
    result.setType(usType);
    result.setData(baData);
    return result.toByteArray();
}

/* Sending SNAC packet */
void QOSCAR::sendSnac(const quint16 usFamId, const quint16 usFamSubType,
                      const quint16 usFlags, const quint32 ulSequence,
                      const QByteArray baData)
{
    QSnac snac;
    snac.setFamilyId(usFamId);
    snac.setSubType(usFamSubType);
    snac.setFlags(usFlags);
    snac.setReqId(ulSequence);
    snac.setData(baData);

    sendFlap(SNAC_CHANNEL, snac.toByteArray(), false);
}

/* Sending FLAP packet */
void QOSCAR::sendFlap(const char cChannel, QByteArray baData,
                      const bool bHello)
{
    QFlap flap(baData, false);
    flap.setChannel(cChannel);
    flap.setSequence(usSequence);
    OSCARSock->Sock->write(flap.toByteArray(bHello));
    incSequence();
}

/* Sending message */
void QOSCAR::sendMessage(const QString SN, const QString Message)
{
    QByteArray baSnac = create_ICBM__MESSAGE_TO_HOST(SN, Message);
    sendFlap(SNAC_CHANNEL, baSnac, false);
}

/* Logging in by MD5-Auth */
void QOSCAR::ms5Login(const QString fSN, const QString fPass)
{
    //
}

/* Uploading SN information */
void QOSCAR::setInfo(const QSNInfo snInfo)
{
    QByteArray bArr;

    QTlv Tlv0154;
    Tlv0154.setType(0x0154);
    Tlv0154.setData((quint16) snInfo.sNickName.length());
    Tlv0154.appendData(snInfo.sNickName);
    bArr.append(Tlv0154.toByteArray());

    QTlv Tlv0140;
    Tlv0140.setType(0x0140);
    Tlv0140.setData((quint16) snInfo.sFirstName.length());
    Tlv0140.appendData(snInfo.sFirstName);
    bArr.append(Tlv0140.toByteArray());

    QTlv Tlv014A;
    Tlv014A.setType(0x014A);
    Tlv014A.setData((quint16) snInfo.sLastName.length());
    Tlv014A.appendData(snInfo.sLastName);
    bArr.append(Tlv014A.toByteArray());

    QTlv Tlv015E;
    Tlv015E.setType(0x015E);
    Tlv015E.setData((quint16) snInfo.sEMail.length());
    Tlv015E.appendData(snInfo.sEMail);
    Tlv015E.appendData((quint8) 0x01);
    bArr.append(Tlv015E.toByteArray());

}

/* Setting status */
void QOSCAR::setStatus(const quint16 usStatus)
{
    //
}
