#include "qoscarsock.h"


/* constructor */
QOSCARSock::QOSCARSock()
{
    Sock = new QSslSocket(this);
    bOnline = false;

    QObject::connect(Sock, SIGNAL(connected()), this, SLOT(fConnected(void)));
    QObject::connect(Sock, SIGNAL(disconnected()), this, SLOT(fDisconnected()));
    QObject::connect(Sock, SIGNAL(error(QAbstractSocket::SocketError)), this, SLOT(fError(QAbstractSocket::SocketError)));
    QObject::connect(Sock, SIGNAL(readyRead()), this, SLOT(fReadyRead()));

}

/* Connecting to host */
void QOSCARSock::connect(const QString fHost, const int fPort)
{
    QString tHost;
    int tPort;

    if ((fHost.length() == 0) || (fPort == 0)){
        tHost = "login.messaging.aol.com";
        tPort = 5190;
    }else{
        tHost = fHost;
        tPort = fPort;
    }
        Sock->connectToHost(tHost, tPort);

    qDebug() << "Connecting to " << tHost;
}

/*************************************/
/********** SIGNALS *****************/
/***********************************/

/* Connected signal */
void QOSCARSock::fConnected(void)
{
    bOnline = true;
    emit sConnected();
}

/* Disconnected signal */
void QOSCARSock::fDisconnected(void)
{
    bOnline = false;
    emit sDisconnected();
}

/* Error signal */
void QOSCARSock::fError(QAbstractSocket::SocketError socketError)
{
    bOnline = false;
    emit sError(socketError);
}

/* ReadyRead Signal */
void QOSCARSock::fReadyRead(void)
{
    emit sReadyRead();
}
