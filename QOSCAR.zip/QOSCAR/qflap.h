#ifndef QFLAP_H
#define QFLAP_H

#include <QObject>
#include <QByteArray>

#include "qoscaradditional.h"

class QFlap : public QObject
{
    Q_OBJECT

    public:
        QFlap(const QByteArray fByteArr, const bool incoming = false);

        void setChannel(const char fChannel) { flapChannel.data = fChannel; }
        void setSequence(const quint16 fSeq) { seqNum.data = fSeq; }

        unsigned char getChannel(void);
        QUShort getSequence(void);
        QUShort getDataSize(void);
        QByteArray getData(void) { return flapData; }
        QByteArray toByteArray(const bool isFirst);
        void deleteArr(const quint32 size);

        unsigned char flapId;
        QUShort8 flapChannel;
        QUShort seqNum;
        QUShort dataSize;
        QByteArray flapData;
        

};

#endif // QFLAP_H
