#ifndef QTLV_H
#define QTLV_H

#include <QObject>
#include <QVariant>
#include <QByteArray>

#include "qoscaradditional.h"

class QTlv : public QObject
{
    Q_OBJECT

    public:
        QTlv(void);

        void handleTlv(const QByteArray fData);

        void setData(const QString &);
        void setData(const QByteArray &);
        void setData(const quint8 &);
        void setData(const quint16 &);
        void setData(const quint32 &);
        void appendData(const QString &);
        void appendData(const quint8 &);
        void appendData(const quint16 &);
        void appendData(const quint32 &);
        void setType(const int fType){ type.data = (quint16) fType; }
        QByteArray toByteArray(void);
        quint16 getLength(void);

        QUShort type;
        QUShort length;
        QByteArray value;
        bool notLast;
};

#endif // QTLV_H
