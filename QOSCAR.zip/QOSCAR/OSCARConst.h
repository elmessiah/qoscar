// QOSCAR constants
#ifndef OSCARCONST_H
#define OSCARCONST_H

#include <QString>

/* Error types */
enum QErrorType {QCONNECTION, QICQ, QCLASS, QOTHER};

/* Array for roasting passwords */
const unsigned char QRoastArray[16] = {0xF3, 0x26, 0x81, 0xC4, 0x39, 0x86, 0xDB, 0x92, 0x71, 0xA3, 0xB9, 0xE6, 0x53, 0x7A, 0x95, 0x7C};

/* Statuses */
enum QStatus {Q_OFFLINE, Q_CONNECTING, Q_CONNECTING_TO_BOS, Q_ONLINE};

/* Struct for ident packet */
struct QIdent {QString clientName;
               quint16 majorVersion;
               quint16 minorVersion;
               quint16 lesserVersion;
               quint16 build;
               quint16 unknown;
               quint32 subBuild;
               QString language;
               QString country;};

/* Struct for messages */
struct QMessage {QString sSender,
                         sMessage,
                         sSendTime;
                 char cMessageType;};


/***************************************/
/* Some constants */
/***************************************/

/* Identifiers */

const char FLAP_IDENT = 0x2A;

const quint16 TLV_BOS_IDENT = 0x0005;
const quint16 TLV_COOKIE_IDENT = 0x0006;


/* Connection types */

const char NEW_CHANNEL = 0x01;
const char SNAC_CHANNEL = 0x02;
const char FLAP_ERR_CHANNEL = 0x03;
const char CLOSE_CHANNEL = 0x04;
const char KEEP_ALIVE_CHANNEL = 0x05;

/* Status Flags */

const quint16 STATUS_WEBAWARE = 0x0001;
const quint16 STATUS_SHOWIP = 0x0002;
const quint16 STATUS_BIRTHDAY  = 0x0008;
const quint16 STATUS_WEBFRONT = 0x0020;
const quint16 STATUS_DCDISABLED = 0x0100;
const quint16 STATUS_DCAUTH = 0x1000;
const quint16 STATUS_DCCONT = 0x2000;

/* Statuses */

const quint16 STATUS_ONLINE = 0x0000;
const quint16 STATUS_AWAY = 0x0001;
const quint16 STATUS_DND = 0x0002;
const quint16 STATUS_NA = 0x0004;
const quint16 STATUS_OCCUPIED = 0x0010;
const quint16 STATUS_FREE4CHAT = 0x0020;
const quint16 STATUS_INVISIBLE = 0x0100;

/* DC Types */

const quint16 DC_DISABLED = 0x0000;
const quint16 DC_HTTPS = 0x0001;
const quint16 DC_SOCKS = 0x0002;
const quint16 DC_NORMAL = 0x0004;
const quint16 DC_WEB = 0x0006;

/* DC Proto versions */

const quint16 DCP_ICQ98 = 0x0004;
const quint16 DCP_ICQ99 = 0x0006;
const quint16 DCP_ICQ2000 = 0x0007;
const quint16 DCP_ICQ2001 = 0x0008;
const quint16 DCP_ICQLITE = 0x0009;
const quint16 DCP_ICQ2003B = 0x000A;

/* Message types */

const char MTYPE_PLAIN = 0x01;
const char MTYPE_CHAT = 0x02;
const char MTYPE_FILEREQ = 0x03;
const char MTYPE_URL = 0x04;
const char MTYPE_AUTHREQ = 0x06;
const char MTYPE_AUTHDENY = 0x07;
const char MTYPE_AUTHOK = 0x08;
const char MTYPE_SERVER = 0x09;
const char MTYPE_ADDED = 0x0C;
const char MTYPE_WWP = 0x0D;
const char MTYPE_EEXPRESS = 0x0E;
const char MTYPE_CONTACTS = 0x13;
const char MTYPE_PLUGIN = 0x1A;
const char MTYPE_AUTOAWAY = 0xE8;
const char MTYPE_AUTOBUSY = 0xE9;
const char MTYPE_AUTONA = 0xEA;
const char MTYPE_AUTODND = 0xEB;
const char MTYPE_AUTOFFC = 0xEC;

/* UUIDs */



/******************/
/* Error codes */
/****************/

const quint16 MISMATCH_NICK_OR_PASSWORD = 0x0005;
const quint16 RATE_LIMITED = 0x0023;

#endif
