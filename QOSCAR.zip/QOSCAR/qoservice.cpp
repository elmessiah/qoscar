#include "qoservice.h"

QOSERVICE::QOSERVICE(const quint16 fusFamNum, const quint16 fusFamVersion,
                     const quint16 fusToolId, const quint16 fusToolVersion)
{
    usFamNum.data = fusFamNum;
    usFamVersion.data = fusFamVersion;
    usToolId.data = fusToolId;
    usToolVersion.data = fusToolVersion;
}

/* To ByteArray */
QByteArray QOSERVICE::toByteArray(void)
{
    QByteArray bArr;
    bArr.append(usFamNum.toByteArray());
    bArr.append(usFamVersion.toByteArray());
    bArr.append(usToolId.toByteArray());
    bArr.append(usToolVersion.toByteArray());
    return bArr;
}

QByteArray create_OSERVICE__CLIENT_ONLINE(void)
{
    QByteArray bArr;

    QOSERVICE OSERVICE1(0x0001, 0x0004, 0x0110, 0x08E4);
    bArr.append(OSERVICE1.toByteArray());

    QOSERVICE OSERVICE19(0x0013, 0x0004, 0x0110, 0x08E4);
    bArr.append(OSERVICE19.toByteArray());

    QOSERVICE OSERVICE2(0x0002, 0x0001, 0x0110, 0x08E4);
    bArr.append(OSERVICE19.toByteArray());

    QOSERVICE OSERVICE3(0x0003, 0x0001, 0x0110, 0x08E4);
    bArr.append(OSERVICE3.toByteArray());

    QOSERVICE OSERVICE21(0x0015, 0x0001, 0x0110, 0x08E4);
    bArr.append(OSERVICE21.toByteArray());

    QOSERVICE OSERVICE4(0x0004, 0x0001, 0x0110, 0x08E4);
    bArr.append(OSERVICE4.toByteArray());

    QOSERVICE OSERVICE6(0x0006, 0x0001, 0x0110, 0x08E4);
    bArr.append(OSERVICE6.toByteArray());

    QOSERVICE OSERVICE9(0x0009, 0x0001, 0x0110, 0x08E4);
    bArr.append(OSERVICE9.toByteArray());

    QOSERVICE OSERVICE10(0x000A, 0x0001, 0x0110, 0x08E4);
    bArr.append(OSERVICE10.toByteArray());

    QOSERVICE OSERVICE11(0x000B, 0x0001, 0x0110, 0x08E4);
    bArr.append(OSERVICE11.toByteArray());

    return bArr;
}
