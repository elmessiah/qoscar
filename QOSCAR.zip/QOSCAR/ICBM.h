#ifndef ICBM_H
#define ICBM_H

#include <QByteArray>
#include <QTextCodec>
#include <QDebug>

#include "qtlv.h"
#include "qsnac.h"
#include "OSCARConst.h"

QMessage handleMessage(const QByteArray baMessage);
QByteArray create_CLI_IDENT(const QIdent ident, const QString ScreenName,
                            const QString Password);
QByteArray create_ICBM__MESSAGE_TO_HOST(const QString SN, const QString Message);

#endif // ICBM_H
